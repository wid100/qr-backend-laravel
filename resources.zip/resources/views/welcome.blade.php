<h1>Hello Smart contract Generator !</h1>
