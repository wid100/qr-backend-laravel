<!-- partial:partials/_footer.html -->
<footer
    class="footer d-flex flex-column flex-md-row align-items-center justify-content-between px-4 py-3 border-top small">
    <p class="text-muted mb-1 mb-md-0">© 2023 <a href="https://www.womenindigital.net/" target="_blank">Women In Digital</a> All Rights Reserved</p>
    <p class="text-muted">Design And Developed By <a href="https://www.womenindigital.net/" target="_blank">Women In Digital</a> | <a href="https://luminadev.com" target="_blank">Lumina Dev</a></p>
</footer>
<!-- partial -->
